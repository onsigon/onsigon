package Fish.fish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FishApplicationTests {

	@Test
	void contextLoads() {
	}

}
